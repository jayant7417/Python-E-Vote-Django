from django.db import models

# Create your models here.
class Store(models.Model):
    check = models.CharField(max_length=15)
    def __str__(self):
        return self.check
