from django.contrib import admin
from .models import Store
# Register your models here.
from import_export.admin import ImportExportModelAdmin
class StoreAdmin(ImportExportModelAdmin,admin.ModelAdmin):
    pass

admin.site.register(Store,StoreAdmin)

